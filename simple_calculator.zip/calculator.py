print("\n>>>>> SIMPLE CALCULATOR <<<<<\n")

init = False
print("Thank you for using our product")

while not init:
    response = int(input("\nPress (1) to continue or (2) to exit \n"))

    if response == 1:
        operation1 = float(input("Please input value: \n"))
        operation2 = float(input("Please input value: \n"))

        request = int(input("Press: "
                            "(1) for addition "
                            "(2) for subtraction "
                            "(3) for multiplication "
                            "(4) for division "
                            "(5) for modulus "
                            "(6) for exponential "
                            "(7) to exit \n"))
        if request == 1:
            result = operation1 + operation2
            print("The result of your addition operation is %d" % result)

        if request == 2:
            result = operation1 - operation2
            print("The result of your subtraction operation is %d" % result)

        if request == 3:
            result = operation1 * operation2
            print("The result of your multiplication operation is %d" % result)

        if request == 4:
            result = operation1 / operation2
            print("The result of your division operation is %d" % result)

        if request == 5:
            result = operation1 % operation2
            print("The result of your modulus operation is %d" % result)

        if request == 6:
            result = operation1 ** operation2
            print("The result of your exponential operation is %d" % result)

        elif request == 7:
            print("Thank you for using simple calculator")
            exit()

        else:
            print("You have entered an invalid response, kindly try again")

    elif response == 2:
        print("Thank you for using simple calculator")
        exit()

    else:
        print("You have entered an invalid response, kindly try again")
